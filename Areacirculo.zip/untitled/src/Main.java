// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        float area;
        float Radio;
        float valor = 3.1416F;
        System.out.println("Programa que nos muestre el area de un circulo");
        System.out.printf("Ingresa el area del circulo:");
        Scanner radio = new Scanner(System.in);
        Radio= radio.nextInt();
        area = (Radio *Radio)*valor;
            System.out.println("El area del circulo es " + area);

    }
}